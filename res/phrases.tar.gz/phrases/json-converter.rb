#!/usr/bin/env ruby

# This file converts DansGuardian phraselists to the much more widely accepted
# Javascipt Object Notation (JSON). It is Ruby code, and is therefore terrible,
# and should not be used by anyone for any purpose whatsoever.
require 'iconv' unless String.method_defined?(:encode)
require 'json'
require 'pp'

phraselistFiles = ARGV
phraselistNames = phraselistFiles.map{ |nom| nom.split("/")[1] }

def wslRecurse(wsl)
  wslNormOne = wsl.select { |x| x[0].length == 1 }
  wslNormGtOne = wsl.select { |x| x[0].length > 1 }

  branches = wslNormOne.map do |phrases, score|
    phrase = phrases[0]
    wrs = [phrase, score]
    # So, at this point, we have each singular phrase, and its associated
    # value. We take each phrase, and find all those in the larger list that
    # begin with that phrase
    br = wslNormGtOne.select { |x| x[0][0] == phrase }
    trimBranches = br.reject{ |b| b.empty? }
    trimmerBranches = trimBranches.map do |phr, sc|
      c = [[phr[1..-1], sc]]
      wslRecurse(c)
    end
    {
      "phrase" => phrase,
      "score" => score,
      "forest" => trimmerBranches
    }
  end
end

hashes = phraselistFiles.map do |phraselistFile| 
  fileText = File::read phraselistFile # Read the file
  if String.method_defined?(:encode)
    fileText.encode!('UTF-8', 'UTF-8', :invalid => :replace)
  else
    ic = Iconv.new('UTF-8', 'UTF-8//IGNORE')
    fileText = ic.iconv(fileText)
  end
  fileLines = fileText.lines     # Linify it
  cleaned = fileLines.map {            # Get rid of superfluous whitespace and comments
      |x| x.strip.split("#")[0]
    }.reject {
      |c| c.nil? or c.empty?
    }
  mrgx = /<(.+)><[0-9]+>/
  cleaned.reject! do |p|
    p.scan(mrgx).flatten[0].nil?
  end
  words = cleaned.map do |p| 
    p.scan(mrgx).flatten[0].strip.split(">,<").map{ |r| r.strip }
  end
  scores = cleaned.map do |p| 
    p.scan(/[0-9]+/)[-1].to_i
  end
  wordsScoresList = words.zip(scores)
  wslRecurse(wordsScoresList)
end

phraseTree = Hash[phraselistNames.zip(hashes)]

print JSON::generate phraseTree
